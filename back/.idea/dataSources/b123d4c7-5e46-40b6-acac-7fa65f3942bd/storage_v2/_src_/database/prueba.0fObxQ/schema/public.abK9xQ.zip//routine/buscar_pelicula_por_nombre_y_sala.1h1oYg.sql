create function buscar_pelicula_por_nombre_y_sala(nombre_buscado character varying, sala_id integer)
    returns TABLE(id_pelicula integer, nombre_pelicula character varying, duracion integer, fecha_publicacion date, id_sala integer, nombre_sala character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        p.id_pelicula,
        p.nombre AS nombre_pelicula,
        p.duracion,
        psc.fecha_publicacion,
        sc.id_sala,
        sc.nombre AS nombre_sala
    FROM
        pelicula p
    INNER JOIN
        pelicula_salacine psc ON p.id_pelicula = psc.id_pelicula
    INNER JOIN
        sala_cine sc ON psc.id_sala_cine = sc.id_sala
    WHERE
        -- Se utiliza ILIKE para una búsqueda insensible a mayúsculas y minúsculas
        -- Se utilizan '%' para buscar coincidencias parciales en el nombre
        p.nombre ILIKE '%' || nombre_buscado || '%'
        AND sc.id_sala = sala_id;
END;
$$;

alter function buscar_pelicula_por_nombre_y_sala(varchar, integer) owner to postgres;

